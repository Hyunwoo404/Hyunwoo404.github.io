package com.FourHour.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.FourHour.dao.BoardDAO;
import com.FourHour.dto.BoardDTO;

@Service
public class BoardService {

	@Autowired
	BoardDAO bDAO;
	
	// 글 목록 조회
	public List<BoardDTO> list(BoardDTO bDTO) {
		return bDAO.list(bDTO);
	}
	// 글 상세 보기
	public List<BoardDTO> detail(int rNo) {
		return bDAO.detail(rNo);
	}
	// 글 작성처리
	public void write(BoardDTO bDTO) {
		bDAO.write(bDTO);
	}
	// 글 수정처리
	public void update(BoardDTO bDTO) {
		bDAO.update(bDTO);
	}
	// 글 삭제 처리
	public void delete(int rNo) {
		bDAO.delete(rNo);
	}
	

	

	
	
}
