package com.FourHour.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;

import com.FourHour.dto.BoardDTO;

public class BoardDAO extends SqlSessionDaoSupport{

	@Autowired
	SqlSessionTemplate session;

	// 글 목록조회
	public List<BoardDTO> list(BoardDTO bDTO) {
		return session.selectList("board.list", bDTO);
	}
	// 글 개수조회
	public int count() {
		return session.selectOne("board.count");
	}
	// 글 상세보기
	public List<BoardDTO> detail(int rNo) {
		return session.selectList("board.detail", rNo);
	}
	// 글 작성처리
	public void write(BoardDTO bDTO) {
		session.insert("board.write", bDTO);
	}
	// 글 수정처리
	public void update(BoardDTO bDTO) {
		session.update("board.update", bDTO);
	}
	// 글 삭제처리
	public void delete(int rNo) {
		session.delete("board.delete", rNo);
	}
	

	
	
	
}
