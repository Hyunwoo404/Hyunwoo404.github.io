package com.FourHour.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.FourHour.dto.BoardDTO;
import com.FourHour.service.BoardService;

@Controller
@RequestMapping("board/")
public class BoardController {
	
	@Autowired
	BoardService bService;
	
	// 리스트
	@RequestMapping("list")
	public String list(BoardDTO bDTO, HttpServletRequest request) {
		request.setAttribute("list", bService.list(bDTO));
		return "board/list";
	}
	// 글 상세
	@RequestMapping("detail")
	public String detail(BoardDTO bDTO, HttpServletRequest request) {
		int rNo = Integer.parseInt(request.getParameter("rNo"));
		request.setAttribute("content", bService.detail(rNo));
		return "board/detail";
	}
	// 글 작성 폼
	@RequestMapping("write")
	public void write() {}
	// 글 작성 처리
	@RequestMapping("writeProc")
	public String writeProc(BoardDTO bDTO) {
		bService.write(bDTO);
		return "redirect:/board/list";
	}
	// 글 수정 폼
	@RequestMapping("modify")
	public void modify(HttpServletRequest request) {
		int rNo = Integer.parseInt(request.getParameter("rNo"));
		request.setAttribute("content", bService.detail(rNo));
	}
	// 글 수정 처리
	@RequestMapping("modifyProc")
	public String modifyProc(BoardDTO bDTO, HttpServletRequest request) {
		int rNo = Integer.parseInt(request.getParameter("rNo"));
		bService.update(bDTO);
		return "redirect:/board/detail?rNo="+rNo;
	}
	// 글 삭제 처리
	@RequestMapping("delete")
	public String delete(HttpServletRequest request) {
		int rNo = Integer.parseInt(request.getParameter("rNo"));
		bService.delete(rNo);
		return "redirect:/board/list";
	}

}
