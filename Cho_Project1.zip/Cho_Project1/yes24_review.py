from bs4 import BeautifulSoup
import requests

fname='C:\\Users\\opsle\\PycharmProjects\\pj2\\data\\review_having.csv'
with open(fname, 'w', encoding='utf-8') as f:
    for i in range(20):
        url='http://www.yes24.com/Product/communityModules/GoodsReviewList/89309569?Sort=1&PageNumber='+str(i)+'&Type=ALL&_=1587800091666'
        recvd=requests.get(url)
        dom=BeautifulSoup(recvd.text,'html.parser')
        divs=dom.find_all('div',{'class':'reviewInfoGrp lnkExtend'})

        for list in divs:
            title=list.find('span',{'class':'txt'}).text        #제목
            em = list.find('em', {'class': 'txt_id'})
            name = em.find('a').text                            #작성자
            date = list.find('em', {'class': 'txt_date'}).text  #날짜
            span=list.find('span',{'class':'review_rating'})
            spans=span.find_all('span')
            score=spans[0].text                                 #평점
            good=list.find('em',{'class':'yes_b txt'}).text     #추천수
            origin=list.find('div',{'class':'reviewInfoBot origin'})
            contents=origin.find('div',{'class':'review_cont'}).text    #내용
            print(title,name,date,score,good,contents)

            makefile='{}-{}-{}-{}-{}-{}\n'.format(title,name,date,score,good,contents)
            # print(str)
            f.write(makefile)