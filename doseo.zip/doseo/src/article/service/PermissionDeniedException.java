package article.service;

public class PermissionDeniedException extends RuntimeException {

}
